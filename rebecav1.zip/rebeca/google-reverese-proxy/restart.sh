docker rm -f nginx-google-docker
docker build -t nginx-google-docker-image-v1 .
sudo mkdir /opt/logs/google-reverse-proxy/
docker run --restart always -itd -v  /opt/logs/google-reverse-proxy/:/var/log/nginx  -p 8001:8001/tcp -p 8081:8081/tcp -p 8086:8086/tcp -p 8886:8886/tcp --name nginx-google-docker nginx-google-docker-image-v1
docker ps -a
------------------------------
sudo tail -f /opt/logs/google-reverse-proxy/access.log


