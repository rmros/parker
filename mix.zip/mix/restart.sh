docker rm -f mix-container
docker build -t mix-image .
sudo mkdir /opt/logs/mix-container/
docker run -itd -v  /opt/logs/mix-container/:/var/log/nginx  --name mix-container -p 8001:8001/tcp -p 8081:8081/tcp -p 8086:8086/tcp -p 8886:8886/tcp -p 80:80/tcp mix-image
docker ps -a
------------------------------
sudo tail -f /opt/logs/mix-container/error.log

