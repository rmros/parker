docker rm -f main-container
docker build -t main-image .
sudo mkdir /opt/logs/main-container/
docker run -itd -v  /opt/logs/main-container/:/var/log/nginx  --name main-container --link=nginx-google-docker -p 80:80 main-image
docker ps -a
------------------------------
sudo tail -f /opt/logs/main-container/access.log

